#include <iostream>
#include <vector>
#include <mutex>
#include <thread>

using namespace std;
std::mutex mu;  //declare a mutex

class Account {
    public:
        Account(int id, std::vector<int>& v)
        : accountNo(id), vec(v)
    {
            cout << "Just created the vector('database') -the balance is " << vec[0] << endl;
    } //end ctor;

    void deposit(double d) {
        std::lock_guard<mutex> lock(mu);
        int balance = vec[0];
        std::thread::id this_id = std::this_thread::get_id();
        std::cout << "thread " << this_id << " about to sleep..." << endl;
        //introduce artificial delay:
        std::this_thread::sleep_for(chrono::microseconds(1000));
        balance+=d;
        vec[0] = balance;    //overwrite the balance
    } //end deposit;

    bool withDraw(double w) {
        std::lock_guard<mutex> lock(mu);
        return true;
    }

    int getBalance() {
       return vec[0];
    }
    private:
        int accountNo;
        vector <int> &vec; //a pretend 'database' that holds the balance
        std::mutex mu;
};


using namespace std;

int main() {
    cout << "main is starting..." << endl;
    vector <int> database (10);
    Account *acct = new Account(1, database);
    std::thread t1(&Account::deposit, std::ref(acct), 500);
    //to prove that both threads update the balance, uncomment the following:
    /* cout << "thread t1 created, main about to sleep..." << endl;
       std::this_thread::sleep_for(chrono::microseconds(1000));
       cout << "main just woke up...thread t2 about to be created..." << endl;
    */
    std::thread t2(&Account::deposit, std::ref(acct), 500);
    t1.join();   //wait for threads to finish
    t2.join();
    cout << "Final balance = " << acct->getBalance() << endl;
    cout << "End of program." << endl;

    return 0;
}
