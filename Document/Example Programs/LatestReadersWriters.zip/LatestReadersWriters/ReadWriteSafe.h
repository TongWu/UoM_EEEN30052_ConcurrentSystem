#ifndef READWRITESAFE_H
#define READWRITESAFE_H
#include <mutex>
#include <condition_variable>

using namespace std;

class ReadWriteSafe
{
    public:
        ReadWriteSafe();
        void acquireRead();
        void releaseRead();
        void acquireWrite();
        void releaseWrite();
        void doRead();
        void doWrite();

    private:
        int readers;
        bool writing;
        std::mutex mu;
        std::condition_variable cv;
};

#endif // READWRITESAFE_H
