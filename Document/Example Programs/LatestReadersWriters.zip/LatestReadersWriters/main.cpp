#include "ReadWriteSafe.h"
#include <iostream>
#include <thread>

using namespace std;


int main() {

    ReadWriteSafe rdwrs;

    cout << "MAIN starting..." << endl;

    // create 5 readers

    std::thread r1(&ReadWriteSafe::doRead, &rdwrs);
    std::thread r2(&ReadWriteSafe::doRead, &rdwrs);
    std::thread r3(&ReadWriteSafe::doRead, &rdwrs);
    std::thread r4(&ReadWriteSafe::doRead, &rdwrs);
    std::thread r5(&ReadWriteSafe::doRead, &rdwrs);

    // create 3 writers

    std::thread w1(&ReadWriteSafe::doWrite, &rdwrs);
    std::thread w2(&ReadWriteSafe::doWrite, &rdwrs);
    std::thread w3(&ReadWriteSafe::doWrite, &rdwrs);

    w1.join(); w2.join(); r1.join(); r2.join(); r3.join();

    cout << "MAIN ending..." << endl;

    return 0;
}
