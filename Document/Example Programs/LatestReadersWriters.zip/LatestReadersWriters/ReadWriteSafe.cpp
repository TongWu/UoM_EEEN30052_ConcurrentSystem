#include "ReadWriteSafe.h"
#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

using namespace std;

    //ctor:
    ReadWriteSafe::ReadWriteSafe() : readers(0), writing(false) {}

	void ReadWriteSafe::acquireRead() {
	    std::unique_lock<mutex> rdlk(mu); //std::unique_lock<mutex> locker(mu);
	    while (writing) {
            std::cout << "I am thread " << std::this_thread::get_id() << " inside acquireRead and about to suspend...\n";
            cv.wait(rdlk);
	    }
	    ++readers;
	}

	void ReadWriteSafe::releaseRead() {
	    std::unique_lock<std::mutex> rdlk(mu);
		--readers;
		if (readers == 0) {
            cv.notify_all();
             std::cout << "I am thread " << std::this_thread::get_id() << " inside releaseRead and notifying...\n";
		}
    }

	void ReadWriteSafe::acquireWrite(){
	    std::unique_lock<std::mutex> wlk(mu);
		while (readers > 0 || writing) {
            std::cout << "I am a writer thread " << std::this_thread::get_id() << " inside acquireWrite and about to suspend...\n";
            cv.wait(wlk);
        }
		writing = true;
		std::cout << "I am a writer thread " << std::this_thread::get_id() << " inside acquireWrite and have just set writing to true...\n";
	}

	void ReadWriteSafe::releaseWrite() {
	    std::unique_lock<std::mutex> wlk(mu);
		writing = false;
		cv.notify_all();
		std::cout << "I am thread " << std::this_thread::get_id() << " inside releaseWrite and notifying...\n";
	}

	void ReadWriteSafe::doRead() {
        int i;
        for (i=0; i<5; i++) {
            acquireRead();
            releaseRead();
        }
    }

    void ReadWriteSafe::doWrite() {
        int i;
        for (i=0; i<5; i++) {
            acquireWrite();
            releaseWrite();
        }
    }


