#include "Account.h"
#include <iostream>
#include <thread>

using namespace std;

 Account::Account(int id, vector<int>& v) //pass in reference to vector
    : accountNo(id), vec(v)
 {
    cout << "Just created the vector('database') -the balance is " << vec[0] << endl;
 } //end ctor

 void Account::deposit(double d) {
    int balance = vec[0];
    std::thread::id this_id = std::this_thread::get_id();
    std::cout << "thread " << this_id << " about to sleep..." << endl;
    //introduce artificial delay:
    std::this_thread::sleep_for(chrono::microseconds(1000));
    balance+=d;
    vec[0] = balance;    //overwrite the balance
 } //end deposit

 bool Account::withDraw(double w) {
    return true;
 }

 int Account::getBalance() {
       return vec[0];
 }
