#ifndef ACCOUNT_H
#define ACCOUNT_H
#include <vector>

using namespace std;

class Account {
    public:
        Account(int id, std::vector<int>& v);
        void deposit(double d);
        bool withDraw(double w);
        int getBalance();
    private:
        int accountNo;
        vector <int> &vec; //a pretend 'database' that holds the balance
};

#endif // ACCOUNT_H
