#include <iostream>
#include <thread>
#include <vector>
#include "Account.h"

using namespace std;

int main()
{
    cout << "main is starting..." << endl;
    vector <int> database (10);
    Account *acct = new Account(1, database);
    std::thread t1(&Account::deposit, std::ref(acct), 500);
    //to prove that both threads update the balance, uncomment the following:
    /* cout << "thread t1 created, main about to sleep..." << endl;
       std::this_thread::sleep_for(chrono::microseconds(1000));
       cout << "main just woke up...thread t2 about to be created..." << endl;
    */
    std::thread t2(&Account::deposit, std::ref(acct), 500);
    t1.join();   //wait for threads to finish
    t2.join();
    cout << "Final balance = " << acct->getBalance() << endl;
    cout << "End of program." << endl;

    return 0;
}
