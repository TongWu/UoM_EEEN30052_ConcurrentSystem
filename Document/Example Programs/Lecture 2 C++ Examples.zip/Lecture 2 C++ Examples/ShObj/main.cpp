#include <iostream>
#include <thread>
using namespace std;

class ShObject { //declare class
  public:
	// public members accessible
	// outside class
		ShObject(int value){x = value;}
	int getX() {return x;}
   void setX(int value) {x = value;}

 private:
	// private members inaccessible
	// outside class
   int x;

}; // end of ShObject

ShObject aSO(1); //global variable:

void inc(){
	//increments x, called by thread t1
  for (int i = 0; i < 10000000; i++) {
    aSO.setX(i);
  }
} //end inc

void print(){
	//prints x, called by thread t2
	cout << " aSO.getX() returns "
		  	<< aSO.getX() << endl;
} //end print

int main() {
 std::cout << "Start of program." << endl;
 std::thread t1(inc);    //t1 starts
 std::thread t2(print);  //t2 starts
 t1.join();//uses join instead of detach,
 t2.join();//and wait for threads to finish
 std::cout << "End of program." << endl;
} //end main

