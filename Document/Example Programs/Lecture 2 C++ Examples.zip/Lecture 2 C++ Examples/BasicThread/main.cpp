#include <iostream>
#include <thread>
using namespace std;

void f1() {
  cout << " Start of thread " << endl;
  for (int i = 0; i < 10; i++) {
    cout << "  thread: " << i << endl;
  }
  cout << "\n***End of thread ***" << endl;
}

int main() {
  thread t(f1);
  t.detach();
	//continue (don't wait for thread to finish)
  cout << " Start of main: " << endl;
  for (int i = 100; i < 110; i++)
    cout << "  main: " << i << endl;

  cout << "\n ***End of main ***" << endl;
}
